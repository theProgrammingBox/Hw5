#pragma once
#include <iostream>
#include <vector>
#include <algorithm>
#include <ctime>

using namespace std;